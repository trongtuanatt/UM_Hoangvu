# -*- coding: utf-8 -*-
"""Tự điền API key debrid từ debrid_preset.json (tạo bởi umbrella_debrid_tool)."""
import os, json, hashlib

def apply():
    try:
        import xbmcaddon, xbmcvfs, xbmcgui
        addon = xbmcaddon.Addon('plugin.video.umbrella')
        base = xbmcvfs.translatePath(addon.getAddonInfo('path'))
        preset = os.path.join(base, 'debrid_preset.json')
        if not os.path.exists(preset): return
        with open(preset, 'rb') as f: raw = f.read()
        digest = hashlib.sha1(raw).hexdigest()
        profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        marker = os.path.join(profile, '.debrid_preset')
        if os.path.exists(marker):
            with open(marker, 'r') as f:
                if f.read().strip() == digest: return
        data = json.loads(raw.decode('utf-8'))
        for key, value in data.items():
            addon.setSetting(key, value)
        if not os.path.exists(profile): xbmcvfs.mkdirs(profile)
        with open(marker, 'w') as f: f.write(digest)
        xbmcgui.Window(10000).clearProperty('umbrella_settings')
    except Exception:
        pass
